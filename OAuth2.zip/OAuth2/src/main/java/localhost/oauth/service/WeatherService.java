package localhost.oauth.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class WeatherService {

    private final RestTemplate restTemplate;
    private final String apiKey;

    @Autowired
    public WeatherService(RestTemplate restTemplate, @Value("${opencage.api.key}") String apiKey) {
        this.restTemplate = restTemplate;
        this.apiKey = apiKey;
    }

    public Map<String, Map<String, Object>> getDailyWeatherData(double latitude, double longitude) {
        LocalDate today = LocalDate.now();
        String url = String.format("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&hourly=temperature_2m&start=%s&end=%s",
                latitude, longitude, today, today.plusDays(30));
        String response = restTemplate.getForObject(url, String.class);

        JSONObject jsonResponse = new JSONObject(response);
        JSONArray times = jsonResponse.getJSONObject("hourly").getJSONArray("time");
        JSONArray temperatures = jsonResponse.getJSONObject("hourly").getJSONArray("temperature_2m");

        Map<String, List<Double>> dailyTemperatures = new HashMap<>();

        for (int i = 0; i < times.length(); i++) {
            String date = times.getString(i).split("T")[0];
            double temperature = temperatures.getDouble(i);

            dailyTemperatures.putIfAbsent(date, new ArrayList<>());
            dailyTemperatures.get(date).add(temperature);
        }

        Map<String, Map<String, Object>> weatherData = new HashMap<>();
        for (Map.Entry<String, List<Double>> entry : dailyTemperatures.entrySet()) {
            double averageTemp = entry.getValue().stream().mapToDouble(Double::doubleValue).average().orElse(0);
            String icon = getWeatherIcon(averageTemp); // Mapear temperatura o condición a un icono
            Map<String, Object> data = new HashMap<>();
            data.put("temperature", averageTemp);
            data.put("icon", icon);
            weatherData.put(entry.getKey(), data);
        }

        // Ordenar las fechas
        return weatherData.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (oldValue, newValue) -> oldValue,
                        TreeMap::new
                ));
    }

    private String getWeatherIcon(double temperature) {
        // Aquí puedes mapear la temperatura a un icono específico de Weather Icons
        if (temperature > 30) {
            return "wi wi-day-sunny";
        } else if (temperature > 20) {
            return "wi wi-day-cloudy";
        } else if (temperature > 10) {
            return "wi wi-cloud";
        } else {
            return "wi wi-snow";
        }
    }

    public double[] getCoordinates(String cityName) {
        String url = String.format("https://api.opencagedata.com/geocode/v1/json?q=%s&key=%s", cityName, apiKey);
        String response = restTemplate.getForObject(url, String.class);

        JSONObject jsonResponse = new JSONObject(response);
        JSONArray results = jsonResponse.getJSONArray("results");

        if (results.isEmpty()) {
            throw new IllegalArgumentException("No se encontraron coordenadas para la ciudad proporcionada");
        }

        JSONObject geometry = results.getJSONObject(0).getJSONObject("geometry");
        double latitude = geometry.getDouble("lat");
        double longitude = geometry.getDouble("lng");

        return new double[]{latitude, longitude};
    }
}
