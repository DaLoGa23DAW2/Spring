package localhost.oauth.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.beans.factory.annotation.Autowired;
import localhost.oauth.service.WeatherService;

import java.util.Map;

@Controller
public class MainController {

    private final WeatherService weatherService;

    @Autowired
    public MainController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/home")
    public String home(Model model, @AuthenticationPrincipal OidcUser principal) {
        if (principal != null) {
            model.addAttribute("name", principal.getAttribute("name"));
        }
        return "home";
    }

    @GetMapping("/weather-form")
    public String weatherForm(Model model, @AuthenticationPrincipal OidcUser principal) {
        if (principal != null) {
            model.addAttribute("name", principal.getAttribute("name"));
        }
        return "weather-form";
    }

    @GetMapping("/weather")
    public String weather(@RequestParam("city") String city, Model model, @AuthenticationPrincipal OidcUser principal) {
        if (principal != null) {
            model.addAttribute("name", principal.getAttribute("name"));
        }
        try {
            double[] coordinates = weatherService.getCoordinates(city);
            Map<String, Map<String, Object>> weatherData = weatherService.getDailyWeatherData(coordinates[0], coordinates[1]);
            model.addAttribute("weatherData", weatherData);
        } catch (Exception e) {
            model.addAttribute("error", "No se pudo obtener la información del clima. Por favor, intente nuevamente.");
        }
        return "weather";
    }
}
